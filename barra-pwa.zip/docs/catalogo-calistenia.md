# Catálogo de calistenia — base de conocimiento

Versión 3 · actualizado 2026-09-22. Generado desde `catalogo-calistenia.json`, que es la fuente de verdad.

## Fuentes

- **PetruWorkout** — [TODAS las FLEXIONES de CALISTENIA explicadas (de fácil a difícil)](https://www.youtube.com/watch?v=D5QklPQm3mI) · catalogo. Ejercicios, orden de progresión, cues y errores. Casi ningún criterio numérico de subida ni programación (series/repes/frecuencia)
- **PetruWorkout** — [Como Empezar y Mejorar tus FLEXIONES (ordenado por niveles)](https://www.youtube.com/watch?v=cGXeQF2qB_E) · escalera. Escalera de 11 niveles de flexiones, qué cuenta como repetición válida y criterios sueltos (15 arqueras)
- **PetruWorkout** — [Como Empezar y Mejorar tus DOMINADAS (ordenado por niveles)](https://www.youtube.com/watch?v=GTnpkjJIPOg) · escalera. Escalera de dominadas de 0 a una mano: isométricos, negativas, explosivas, muscle up, en L, cadera, lastre
- **PetruWorkout** — [TODOS los ejercicios de PINO Explicados - Desde nivel 0 hasta EXPERTO](https://www.youtube.com/watch?v=78pjvDxppXk) · habilidad. Técnica del pino, progresiones con pared y paralelas, requisitos de flexiones de pino y pino a una mano
- **PetruWorkout** — [10 Habilidades de Calistenia que vas a aprender (en orden)](https://www.youtube.com/watch?v=9zF0cTb51Ao) · habilidad. Orden de habilidades, requisitos (20 s colgado, 30 s plancha), rana/enanito, L-sit, pino por fuerza, back/front lever, una mano
- **PetruWorkout** — [Los 10 MEJORES ejercicios que deberías hacer por el resto de tu vida (sin gym)](https://www.youtube.com/watch?v=Wh1wwVkZBlY) · catalogo. Básicos con escalado: dominadas (15 → variantes), remos, fondos, plancha, elevaciones de piernas, sentadilla
- **PetruWorkout** — [Los 7 Niveles de un PRINCIPIANTE en Calistenia](https://www.youtube.com/watch?v=W4Jzvg7qZLE) · motivacional. Casi nada accionable: confirma el orden rana → enanito → pino → flexiones de pino
- **PetruWorkout** — [5 PASOS para Perder Grasa Abdominal](https://www.youtube.com/watch?v=_kWHwxEpSAs) · fuera_de_alcance. Nutrición, sueño y hábitos. Va al proyecto de comidas, no al tracker
- **Domein** — [Como armar una RUTINA de CALISTENIA (principiantes, intermedios, avanzados)](https://www.youtube.com/watch?v=wBtOM89nsXg) · programacion. Estructura de sesión: preparación → práctica → refuerzo; series, repeticiones y descansos
- **algecalistenia** — [VOLUMEN e INTENSIDAD en CALISTENIA](https://www.youtube.com/watch?v=kQqfoxGyMyM) · programacion. Regla de progresión: series al fallo técnico o RIR 1, volumen que crece solo y cambio de ejercicio; explosivos y fallo
- **Bruno Focacci** — [¡De 0 a FULL PLANCHE! | Lo Que YO Haría](https://www.youtube.com/watch?v=8yekTu2j_0s) · habilidad. Escalera completa de plancha con criterios de paso en segundos (15 s lean/tuck, 12–15 s adv tuck, 10 s straddle, 7–10 s half)
- **Pedro Gadez** — [Los secretos del Press a Tuck Planche (Técnica, Mentalidad y Progresión)](https://www.youtube.com/watch?v=HsvCjXt7sCI) · habilidad. Requisitos y progresión del press a tuck planche, técnica y errores
- **Eryc Ortiz** — [COMO PROGRESAR MÁS RÁPIDO EN LA CALISTENIA](https://www.youtube.com/watch?v=POcz4T5OrBQ) · tecnica. 5 modificaciones: dominada alta, fondos con depresión escapular, candlestick, HSPU déficit, palmadas

Descartados: Bienvenido.md (nota por defecto de Obsidian, sin contenido); contexto-tracker-calistenia.md (documento de contexto, no es un clipping)

## Principios de programación

- **Progresión.** Series al fallo técnico o a 1 repetición en recámara (RIR 1), con repeticiones o segundos variables. Al ganar fuerza el volumen sube solo; al llegar al volumen objetivo, pasas a un ejercicio más difícil y vuelves a volumen bajo. _(algecalistenia 3:42)_
- **Progresión.** Convierte volumen en intensidad: cuando una progresión se aguanta 10–15 s o sale con volumen cómodo, pasa a la siguiente. _(Bruno Focacci 8:23)_
- **Progresión.** Con 15 dominadas limpias, progresa a variantes en lugar de sumar repeticiones. _(PetruWorkout 1:27)_
- **Fallo.** Habilidades: fallo técnico (plancha: protracción y brazos rectos; front lever: brazos rectos y retracción). Básicos (dominadas, fondos, flexiones): se puede llegar al fallo muscular. _(algecalistenia 9:52)_
- **Fallo.** Series cortas e intensas pueden ir al fallo; series largas al principio de la sesión, no, porque fríen el resto del entreno. _(algecalistenia 11:11)_
- **Explosividad.** Trabajo explosivo en series de 3–4 repeticiones; para cuando pierdas velocidad o altura. _(algecalistenia 7:46)_
- **Estructura.** Sesión en tres partes: preparación (movilidad, core, escápulas, series de aproximación) → práctica (el ejercicio objetivo, con descanso largo) → refuerzo (superseries de 6–8 y luego de 8–12). _(Domein 2:17)_
- **Estructura.** Práctica de fuerza: 3–5 series de 2–5 repeticiones, descansando 2–4 min, más cuanto más fatiga. Habilidades técnicas (subidas a pino…): 15–20 min de intentos en lugar de contar series. _(Domein 6:45)_
- **Objetivos.** Elige como objetivo un ejercicio del que haces 1–2 repeticiones y llévalo a 5–6. _(Domein 1:06)_
- **Pino.** Practica el pino todos los días; los de descanso, menos intentos pero sin dejarlo. _(PetruWorkout 2:18)_
- **Plancha.** Mientras entrenas plancha, mantén el pino y las flexiones de pino: empuje en todos los ángulos. _(Bruno Focacci 3:50)_
- **Negativas y goma.** Domina la negativa antes que la positiva. La goma sirve para aprender la técnica, no para construir la fuerza. _(Bruno Focacci 18:49)_
- **Técnica.** Grábate para comprobar la técnica; tras el entreno apunta qué falló y qué salió bien. _(Pedro Gadez 14:51)_

## Conflictos entre fuentes

- **Cuándo empezar flexiones en tuck planche.** Petru: tras aguantar la tuck planche ~5 s. Bruno Focacci: tras 15 s sólidos de tuck. → Tracker: Se usa el de Bruno (más conservador); cámbialo si te convence Petru
- **Profundidad de la flexión de pino en pared.** Petru (catálogo de flexiones): hasta casi tocar el suelo con la nariz. Petru (vídeo de niveles) y Eryc Ortiz: codos a 90º, déficit progresivo. → Tracker: Parcial = hasta 90º, completa = cabeza al suelo, déficit después
- **Orden entre dominada al abdomen y muscle up.** Eryc Ortiz: pecho → abdomen → cadera. Petru: explosiva → muscle up → … → cadera. → Tracker: Pecho → muscle up → abdomen → cadera
- **Estructura semanal.** Tu plan: empuje y tirón en días separados. Domein: empuje y tirón en la misma sesión (aunque dice que separarlos también vale). → Tracker: Se mantiene tu A/B

## Pendientes

- Pierna: ninguna fuente enseña búlgara, shrimp o pistol. La escalera de pierna sigue sin fuente
- Dragon flag: sin fuente; se ha quitado del tracker y el candlestick de Eryc ocupa su lugar
- Nivel de fondos y aguante de pino: necesarios para saber si cumples los requisitos de plancha (20–25 fondos) y de flexión de pino libre (10–15 s de pino)
- Material: paralelas bajas o parallettes para plancha y L-sit

## Material confirmado

- barra
- paralelas
- pared (parque)
- goma elástica
- mochila para lastre

## Base: hasta la flexión clásica (`base_flexion`)

1. **Flexión en pared** `flex_pared` (pared) — PetruWorkout 1:20; PetruWorkout 0:46
   - ✓ Manos a la altura del pecho, algo más abiertas que los hombros
   - ✓ Codos hacia atrás pegados al cuerpo, nunca abiertos hacia los lados
   - ✓ Cuanto más atrás los pies, más inclinado y más difícil
   - ✗ Abrir los codos hacia los lados (carga el hombro)
2. **Flexión inclinada** `flex_inclinada` (superficie elevada) — PetruWorkout 2:05; PetruWorkout 1:01
   - ✓ Cuanto más alta la superficie, más fácil
   - ✓ Bajar la altura en cuanto deje de costar, hasta llegar al suelo
   - ✓ Progresión de alturas: mesa → silla → suelo
   - ↑ Pasar a una superficie más baja cuando te resulte cómoda
3. **Flexión con rodillas** `flex_rodillas` — PetruWorkout 2:44; PetruWorkout 1:33
   - ✓ Cuerpo en línea recta: abdomen y glúteo apretados (cabeza a rodillas)
   - ✓ Bajar hasta rozar el pecho con el suelo
   - ✓ Imagina un palo de escoba de la cabeza a las rodillas: todo el cuerpo lo toca
   - ✗ Dejar caer la cadera y arquear la espalda
   - ↑ No pasar de nivel si cuesta llegar a 10 repes con buena técnica
   - ↑ Grábate: si no sale como en el vídeo, vuelve al nivel anterior (PetruWorkout)
4. **Flexión negativa** `flex_negativa` (negativa) — PetruWorkout 3:30
   - ✓ Bajar lo más lento posible (contar ~3 s)
   - ✓ Abajo apoyar rodillas y volver arriba
   - ℹ El autor la señala como la que más fuerza real da del bloque inicial; cuanto más lenta la bajada, más fuerza
5. **Flexión con goma** `flex_goma` (goma elástica, barra) — PetruWorkout 4:17
   - ✓ Goma atada por encima sujetando cadera o pecho
   - ℹ Puente entre rodillas y flexión completa
6. **Flexión clásica** `flex_clasica` — PetruWorkout 4:41; PetruWorkout 2:09
   - ✓ Manos algo más abiertas que los hombros
   - ✓ Cuerpo en línea recta: abdomen y glúteo apretados
   - ✓ Codos hacia atrás pegados al cuerpo, nunca abiertos hacia los lados
   - ✓ Bajar hasta rozar el pecho con el suelo
   - ✓ Pausa de 1 s arriba y 1 s abajo
   - ↑ 10 perfectas ya es buen nivel; prioriza técnica sobre número
   - ↑ Repetición válida: brazos totalmente estirados y pecho a 2 cm del suelo; las medias no cuentan (PetruWorkout)
7. **Flexión con pausa abajo** `flex_pausa` — PetruWorkout 5:20
   - ✓ Pausa de 2–3 s abajo antes de subir
   - ✓ Elimina el impulso

## Variantes de agarre y estabilidad (`variantes_agarre`)

_Accesorios del mismo nivel que la clásica; el orden es el del vídeo, no de dificultad_

1. **Flexión estrecha** `flex_estrecha` — PetruWorkout 5:41
   - ✓ Manos a la anchura de los hombros o algo menos
   - ℹ Más tríceps
2. **Flexión diamante** `flex_diamante` — PetruWorkout 5:41; PetruWorkout 3:35
   - ✓ Pulgares e índices tocándose bajo el pecho
   - ✓ Si molestan las muñecas: manos rectas y algo separadas
   - ℹ Más tríceps
3. **Flexión agarre medio** `flex_agarre_medio` — PetruWorkout 5:41
4. **Flexión abierta** `flex_abierta` — PetruWorkout 6:13; PetruWorkout 3:14
   - ✓ Manos más separadas de lo normal
   - ✓ Manos lo más separadas posible, dedos apuntando hacia fuera
   - ℹ Más pecho. El autor la recomienda especialmente porque es la base de las variantes unilaterales posteriores
5. **Flexión escalonada** `flex_escalonada` — PetruWorkout 6:50
   - ✓ Una mano adelantada
   - ✓ Mitad de repes por lado
   - ℹ Puente hacia flexión a un brazo
6. **Flexión agarre inverso** `flex_inversa` — PetruWorkout 7:30
   - ✓ Dedos apuntando a los pies
   - ✓ Ir con calma; no bajar del todo si molesta la muñeca
   - ℹ Trabaja antebrazo y bíceps
7. **Flexión agarre inverso a la cadera** `flex_inversa_cadera` — PetruWorkout 8:11
   - ✓ Manos casi a la altura de la cadera, dedos hacia los pies
   - ↑ Si tiembla mucho la muñeca, quedarse en la inversa normal
8. **Flexión con movimiento lateral** `flex_mov_lateral` — PetruWorkout 8:39
   - ✓ Desde abierta: tras cada repe, desplazarse a un lado y alternar
9. **Toques de hombro en plancha** `plancha_toques_hombro` — PetruWorkout 9:20
   - ✓ Cadera inmóvil
   - ✓ Apretar abdomen y glúteo antes de mover la mano
   - ✗ Balancear la cadera para compensar

## Declinadas y déficit (`declinada_deficit`)

_Diamante/abierta de la declinada son variantes laterales, no peldaños obligatorios_

1. **Flexión declinada** `flex_declinada` (superficie elevada) — PetruWorkout 10:02; PetruWorkout 4:14
   - ✓ Pies elevados
   - ✓ Codos hacia atrás pegados al cuerpo, nunca abiertos hacia los lados
   - ✓ Cuerpo en línea recta: abdomen y glúteo apretados
   - ✓ Cuanto más altos los pies, más hombro: prepara las flexiones de pino
   - ✗ Dejar caer la cadera y arquear la zona lumbar
2. **Flexión declinada diamante** `flex_declinada_diamante` (superficie elevada) — PetruWorkout 10:56
   - ℹ Tríceps al máximo
3. **Flexión declinada abierta** `flex_declinada_abierta` (superficie elevada) — PetruWorkout 10:56
   - ℹ Más pecho
4. **Flexión con déficit (profunda)** `flex_deficit` (dos apoyos elevados (bloques, paralelas bajas)) — PetruWorkout 11:14
   - ✓ El pecho baja por debajo del nivel de las manos
   - ✗ Ir al rango máximo el primer día (riesgo de hombro)
   - ↑ Aumentar la profundidad unos centímetros por semana, no de golpe
5. **Flexión déficit manos juntas** `flex_deficit_juntas` (dos apoyos elevados) — PetruWorkout 12:02
6. **Flexión declinada + déficit** `flex_declinada_deficit` (dos apoyos elevados, superficie elevada) — PetruWorkout 12:12
   - ℹ Suma dos fuentes de dificultad; sin prisa

## Camino a la flexión a una mano (`camino_una_mano`)

_Une el bloque arquera/typewriter (13:47–15:05) con el bloque una mano (26:22–28:09)_

1. **Flexión con carga en un brazo** `flex_carga_un_brazo` — PetruWorkout 12:26
   - ✓ Desde abierta, una mano hace casi todo; la otra solo roza
   - ✗ Empujar con las dos por igual
2. **Flexión a una mano con rodillas** `flex_una_mano_rodillas` — PetruWorkout 13:12
   - ✓ Mano centrada
   - ✓ La otra mano en superficie algo elevada
   - ↑ Mantener varias semanas antes de quitar las rodillas
3. **Flexión arquera** `flex_arquera` — PetruWorkout 13:47; PetruWorkout 4:49
   - ✓ Muy abierto; bajar hacia un lado con el otro brazo totalmente estirado
   - ✓ Bajar hasta rozar el pecho con el suelo
   - ✗ No estirar del todo el codo
   - ✗ No bajar del todo
   - ↑ 15 repeticiones limpias = muy buena fuerza de brazo (PetruWorkout)
   - ℹ Regresión: con rodillas apoyadas · Regresión: manos menos abiertas y el brazo estirado medio flexionado
4. **Flexión typewriter** `flex_typewriter` — PetruWorkout 14:31
   - ✓ Quedarse abajo y desplazarse de lado a lado sin subir
5. **Flexión lateral** `flex_lateral` — PetruWorkout 15:05
   - ✓ Como dos arqueras seguidas: bajar a un lado, subir, cambiar
6. **Flexión a una mano con apoyo (agarrando)** `flex_una_mano_apoyo` (superficie elevada) — PetruWorkout 26:22
   - ✓ Piernas muy abiertas
   - ✓ Mano de trabajo en el centro del pecho; la otra se agarra a algo elevado
7. **Flexión a una mano, apoyo elevado sin agarrar** `flex_una_mano_apoyo_elevado` (superficie elevada) — PetruWorkout 26:40
   - ✓ La mano libre solo se apoya para equilibrio
8. **Flexión a una mano negativa** `flex_una_mano_negativa` (negativa) — PetruWorkout 5:53
   - ✓ Solo la bajada, apretando fuerte; vuelve arriba con ayuda
9. **Flexión a una mano piernas abiertas** `flex_una_mano_piernas_abiertas` — PetruWorkout 27:01; PetruWorkout 5:25
   - ✓ Piernas muy separadas
   - ✓ Mano libre a la espalda
   - ✓ Cadera sin girar
   - ✓ Codos hacia atrás pegados al cuerpo, nunca abiertos hacia los lados
10. **Flexión a una mano estricta** `flex_una_mano` — PetruWorkout 27:27; PetruWorkout 5:25
   - ✓ Piernas algo más juntas
   - ✓ Mano centrada bajo el pecho
   - ✓ Equilibrio con abdomen y glúteo
   - ✓ Piernas abiertas, mano de trabajo en el centro
11. **Flexión a una mano con déficit** `flex_una_mano_deficit` (apoyo elevado) — PetruWorkout 27:50
   - ℹ Muy exigente para el hombro; solo con buena base
12. **Flexión a una mano declinada** `flex_una_mano_declinada` (superficie elevada) — PetruWorkout 28:09

## Auxiliares de tríceps y hombro (`auxiliares_triceps_hombro`)

1. **Flexión de tríceps** `flex_triceps` — PetruWorkout 15:42
   - ✓ Manos bajo el pecho, algo más juntas que la clásica
   - ✓ Codos rozando las costillas todo el recorrido
   - ✓ Bajada lenta
   - ✗ Separar los codos (pasa a trabajar pecho)
2. **Tiger bend negativa** `tiger_bend_negativa` (negativa) — PetruWorkout 16:50
   - ✓ Bajar lento hasta apoyar antebrazos; volver arriba apoyando rodillas
3. **Tiger bend push-up** `tiger_bend` — PetruWorkout 16:16
   - ✓ Bajar hasta apoyar los antebrazos y empujar hasta estirar los brazos
   - ℹ Según el autor, de los mejores para preparar hombro y tríceps de cara a la plancha
4. **Transferencia de peso en plancha** `transferencia_peso` — PetruWorkout 17:04
   - ✓ Brazos estirados, pies fijos; llevar el peso adelante y atrás
   - ✓ Lento y controlado
   - ✗ Hacerlo rápido o brusco

## Explosivas (`explosivas`)

1. **Flexión explosiva** `flex_explosiva` — PetruWorkout 17:47
   - ✓ Bajada controlada, subida lo más rápida posible sin despegar
2. **Flexión con despegue de manos** `flex_despegue` — PetruWorkout 18:13
   - ✓ Amortiguar la caída con codos ligeramente flexionados
   - ✗ Caer con los brazos rígidos
3. **Flexión con palmada bajo el pecho** `flex_palmada_pecho` — PetruWorkout 18:35; Eryc Ortiz 6:02
   - ✓ Aterriza con los dedos y luego la palma, no con impacto en la muñeca
   - ✓ No uses la cadera para impulsarte
4. **Flexión con palmada frontal** `flex_palmada_frontal` — PetruWorkout 18:35
5. **Flexión con doble palmada** `flex_doble_palmada` — PetruWorkout 18:35
6. **Flexión con palmada en la espalda** `flex_palmada_espalda` — PetruWorkout 18:35
7. **Flexión explosiva con desplazamiento** `flex_explosiva_desplazamiento` — PetruWorkout 19:25
   - ✓ Aterrizar centrado, ambas manos a la misma altura
8. **Flexión 180º** `flex_180` — PetruWorkout 19:52
9. **Flexión 360º** `flex_360` — PetruWorkout 20:08
   - ↑ Solo cuando la de 180º sale con soltura y segura
10. **Flexión Superman** `flex_superman` — PetruWorkout 20:30
11. **Flexión azteca** `flex_azteca` — PetruWorkout 20:55
   - ✓ Despegue + flexión de cadera; tocar los pies con las manos
   - ↑ Solo con las explosivas anteriores dominadas

## Pica → pino (`empuje_vertical`)

1. **Flexión pica** `flex_pica` — PetruWorkout 21:55
   - ✓ V invertida, cadera muy alta
   - ✓ Bajar la cabeza en diagonal hacia el suelo
   - ✗ No subir suficiente la cadera (se convierte en flexión normal)
   - ℹ El autor pide dedicarle mucho tiempo: puente hacia el pino
2. **Flexión pica pies elevados** `flex_pica_pies_elevados` (superficie elevada) — PetruWorkout 22:44
   - ✓ Cuerpo más vertical = más hombro
3. **Flexión pica con déficit** `flex_pica_deficit` (dos apoyos elevados) — PetruWorkout 22:44
4. **Flexión pica pies elevados + déficit** `flex_pica_pies_elevados_deficit` (dos apoyos elevados, superficie elevada) — PetruWorkout 22:44
   - ↑ Subir de variante de una en una; no mezclarlas el primer día
5. **Flexión pica unilateral** `flex_pica_unilateral` — PetruWorkout 23:08
   - ✓ Una mano hace casi todo; la otra solo equilibra
   - ℹ Paso hacia el pino a una mano
6. **Flexión de pino asistida** `hspu_asistida` (goma elástica o compañero) — PetruWorkout 23:31
7. **Flexión de pino contra pared (rango parcial)** `hspu_pared_parcial` (pared) — PetruWorkout 23:54
   - ✓ Bajar solo lo que permita volver a subir; la repe tiene que completarse
8. **Flexión de pino contra pared (rango completo)** `hspu_pared` (pared) — PetruWorkout 24:36; PetruWorkout 6:03; Eryc Ortiz 4:42
   - ✓ Bajar hasta casi tocar el suelo con la cabeza, con control
   - ✓ Fija la mirada en un punto del suelo, sin mover la cabeza
   - ✓ Si no llegas abajo, haz mini-flexiones
   - ✓ Sin perder el abdomen ni arquear la espalda
   - ↑ Quedarse varias semanas aquí antes de complicarlo
   - ℹ Según el autor, aquí se construye la fuerza de hombro real
9. **Flexión de pino contra pared con déficit** `hspu_pared_deficit` (pared, dos apoyos elevados) — PetruWorkout 24:59; Eryc Ortiz 5:01
   - ✓ Profundidad progresiva: empieza a 90º y baja poco a poco por debajo del suelo
   - ↑ Solo cuando el rango completo contra la pared resulte cómodo
10. **Flexión de pino libre** `hspu_libre` — PetruWorkout 25:24; PetruWorkout 6:35; PetruWorkout 3:20; PetruWorkout 9:20
   - ✓ Todo el cuerpo rígido, abdomen al máximo
   - ✓ Equilibrio con las yemas de los dedos
   - ✓ Aprieta abdomen, glúteos y piernas
   - ✓ No lleves las piernas atrás: mantenlas cerca del eje
   - ✓ Al bajar, lleva el cuerpo un poco hacia atrás sin arquear, sin exagerar
   - ↑ Requisito: pino dominado, 10–15 s de aguante; la fuerza se construye con muchísimas en pared (PetruWorkout)
   - ↑ Para el pino a una mano: 5 flexiones de pino libres (PetruWorkout)
   - ℹ Limita el control/equilibrio más que la fuerza; no tener prisa por dejar la pared
11. **Flexión de pino con palmada** `hspu_palmada` — PetruWorkout 26:04; PetruWorkout 7:29
   - ℹ Para llegar aquí el autor recomienda flexiones de pino todos los días salvo uno

## Pseudoplancha → full planche (`plancha`)

1. **Lean planche (estático)** `lean_planche` (segundos) — PetruWorkout 28:36; Bruno Focacci 1:08
   - ✓ Brazos estirados, hombros por delante de las manos
   - ✓ Protracción escapular (joroba arriba), pecho hundido
   - ✓ Depresión de hombros, pecho activo; inclínate empujando hacia arriba
   - ↑ 15 s de lean planche para pasar a tuck planche; si es fácil, pies elevados (Bruno Focacci)
   - ℹ El autor recomienda practicar mucho la posición antes de la flexión
2. **Flexión lean planche (pseudoplancha)** `flex_lean_planche` — PetruWorkout 29:20; PetruWorkout 6:12; Bruno Focacci 2:29
   - ✓ Manos a la altura de la cadera, hombros adelantados
   - ✓ Mantener la protracción
   - ✓ Codos hacia atrás pegados al cuerpo, nunca abiertos hacia los lados
   - ✓ Gira las muñecas para que queden laterales
   - ✓ Primero aguanta arriba con brazos rectos practicando hundir el pecho
   - ✓ Hombros lejos de las orejas
   - ✓ La subida va hacia delante, hacia la palanca
   - ℹ Cuanto más cerca de la cadera las manos, más carga en hombros
3. **Flexión lean planche pies elevados** `flex_lean_planche_elevada` (superficie elevada) — PetruWorkout 29:56
4. **Flexión lean planche con déficit** `flex_lean_planche_deficit` (dos apoyos elevados) — PetruWorkout 30:10
   - ↑ Solo cuando la versión estándar sea cómoda y controlada
5. **Flexión tuck planche** `flex_tuck_planche` (paralelas bajas (recomendable)) — PetruWorkout 30:29; Bruno Focacci 7:02
   - ✓ Rodillas al pecho, pies en el aire, hombros adelantados
   - ↑ Antes: mantener la tuck planche estática al menos ~5 s
   - ↑ Empezar cuando el tuck es sólido (15 s) (Bruno Focacci)
6. **Flexión advanced tuck planche** `flex_adv_tuck_planche` — PetruWorkout 31:10
   - ✓ Rodillas más separadas del pecho, cuerpo más horizontal
7. **Flexión straddle planche** `flex_straddle_planche` — PetruWorkout 31:29; PetruWorkout 7:47
   - ✓ Piernas estiradas y abiertas en V
   - ℹ El autor la muestra con goma
8. **Flexión full planche** `flex_full_planche` — PetruWorkout 31:58
   - ✓ Piernas juntas, cuerpo horizontal

## Élite (`elite`)

1. **Flexión de pino a 90º (90º push-up)** `flex_pino_90` — PetruWorkout 32:40; PetruWorkout 4:11
   - ℹ Se consigue con muchísimas flexiones de pino y mucha plancha abdominal
2. **Flexión maltese** `flex_maltese` — PetruWorkout 33:04
   - ℹ Recomendado adaptarse con goma
3. **Plancha a una mano** `plancha_una_mano` (segundos) — PetruWorkout 33:29

## Pino: equilibrio (`pino_equilibrio`)

1. **Pino con hombros apoyados en paralelas** `pino_paralelas_hombros` (segundos; paralelas) — PetruWorkout 2:39
   - ✓ Hombros sobre una barra, manos agarrando la otra; sube las piernas poco a poco
   - ℹ El pino más fácil: no te puedes caer hacia delante
2. **Pino caminando por la pared (pecho a la pared)** `pino_pared_caminando` (segundos; pared) — PetruWorkout 2:13; PetruWorkout 4:49; PetruWorkout 4:57
   - ✓ Desde posición de flexión, sube los pies por la pared hasta donde te sientas seguro y aguanta
   - ℹ El autor lo recomienda primero porque quita el miedo
3. **Pino de espaldas a la pared (patada)** `pino_pared_espaldas` (segundos; pared) — PetruWorkout 1:48; PetruWorkout 5:30
   - ✓ Patada y apoya los dos pies; cuando estés cómodo suelta uno
   - ✓ Céntrate en las manos y los dedos
   - ✓ Ve despegándote de la pared poco a poco
   - ℹ Hacia delante te protege la pared; hacia atrás caes de pie
4. **Pino libre** `pino_libre` (segundos) — PetruWorkout 0:00; PetruWorkout 4:44
   - ✓ Dedos algo flexionados, agarrando el suelo: si te vas adelante, presiona con los dedos; si te vas atrás, relaja
   - ✓ Todo apretado: piernas estiradas, glúteos, abdomen, hombros empujando el suelo
   - ✓ Para salir: quita una mano y el cuerpo gira solo
   - ✗ Posición banana (espalda arqueada): corrígela con movilidad de hombros y retroversión pélvica
   - ↑ Practícalo todos los días; los días de descanso, menos intentos pero no lo dejes (PetruWorkout)
5. **Pino a una mano** `pino_una_mano` (segundos; paralelas) — PetruWorkout 4:30; PetruWorkout 9:20
   - ✓ En paralelas es más sencillo
   - ✓ Estírate hacia arriba (extensión de hombros) y lleva el peso a un lado
   - ✓ Retira la mano poco a poco: agarre → dedos → dos dedos → uno
   - ✓ Aprieta fuerte la paralela para estabilizar
   - ✓ Piernas abiertas
   - ↑ Requisitos: 30 s de pino con buena posición y 5 flexiones de pino libres (PetruWorkout)

## Rana → pino por fuerza (`pino_fuerza`)

1. **Rana (apoyo de codos en muslos)** `rana` (segundos) — PetruWorkout 2:11
   - ✓ Codos en el interior de los muslos, flexiónalos un poco
   - ✓ Échate adelante, sube un pie y luego el otro
   - ↑ Con 10 s pasas al enanito (PetruWorkout)
2. **Enanito (sin apoyar muslos en codos)** `enanito` (segundos) — PetruWorkout 3:09
   - ✓ Baja un poco los codos e intenta subir los dos pies
   - ✓ Si cuesta, deja un pie en el suelo
3. **Subida a pino por fuerza (codos flexionados)** `pino_fuerza` — PetruWorkout 7:46; Pedro Gadez 1:20
   - ✓ Desde enanito, aguanta 2 s y sube a pino
   - ✓ También desde L-sit o en paralelas
   - ↑ Requisito: flexiones de pino en pared a 90º (PetruWorkout)
   - ℹ Según Pedro Gadez va antes que cualquier trabajo de plancha: más natural y sano que empujar con codos estirados

## Lean → full planche (aguantes) (`plancha_aguante`)

_Criterios de paso de Bruno Focacci en segundos_

1. **Lean planche (estático)** `lean_planche` (segundos) — PetruWorkout 28:36; Bruno Focacci 1:08
   - ✓ Brazos estirados, hombros por delante de las manos
   - ✓ Protracción escapular (joroba arriba), pecho hundido
   - ✓ Depresión de hombros, pecho activo; inclínate empujando hacia arriba
   - ↑ 15 s de lean planche para pasar a tuck planche; si es fácil, pies elevados (Bruno Focacci)
   - ℹ El autor recomienda practicar mucho la posición antes de la flexión
2. **Tuck planche (aguante)** `tuck_planche` (segundos; paralelas) — Bruno Focacci 5:30; Pedro Gadez 2:05
   - ✓ Agarra fuerte, rodillas juntas al pecho, palanca de hombro como en el lean
   - ↑ 15 s sólidos para pasar a advanced tuck y empezar flexiones en tuck (Bruno Focacci)
3. **Advanced tuck planche (aguante)** `adv_tuck_planche` (segundos; paralelas) — Bruno Focacci 6:38
   - ✓ Rodillas separadas del pecho, llevándolas hacia atrás
   - ↑ 12–15 s para empezar la transición a straddle (Bruno Focacci)
4. **Straddle planche con goma** `straddle_planche_goma` (segundos; goma elástica, paralelas) — Bruno Focacci 12:48
   - ↑ Goma que te deje aguantar 5–7 s con esfuerzo (Bruno Focacci)
5. **Straddle planche (aguante)** `straddle_planche` (segundos) — Bruno Focacci 13:11
   - ↑ ~10 s para ir a por straddle press y flexiones en straddle (negativa primero, 3–5 s, 2–3 repes) (Bruno Focacci)
6. **Half lay planche (aguante)** `half_lay_planche` (segundos) — Bruno Focacci 13:37
   - ↑ 7–10 s para empezar intentos de full planche (Bruno Focacci)
7. **Full planche (aguante)** `full_planche` (segundos) — Bruno Focacci 16:33
   - ℹ Trabajo de acercamiento: lanzadas, elevaciones desde lean, negativas desde pino y aguantes con goma al final

## Flexiones de plancha (`plancha_flexiones`)

1. **Flexión lean planche (pseudoplancha)** `flex_lean_planche` — PetruWorkout 29:20; PetruWorkout 6:12; Bruno Focacci 2:29
   - ✓ Manos a la altura de la cadera, hombros adelantados
   - ✓ Mantener la protracción
   - ✓ Codos hacia atrás pegados al cuerpo, nunca abiertos hacia los lados
   - ✓ Gira las muñecas para que queden laterales
   - ✓ Primero aguanta arriba con brazos rectos practicando hundir el pecho
   - ✓ Hombros lejos de las orejas
   - ✓ La subida va hacia delante, hacia la palanca
   - ℹ Cuanto más cerca de la cadera las manos, más carga en hombros
2. **Flexión lean planche pies elevados** `flex_lean_planche_elevada` (superficie elevada) — PetruWorkout 29:56
3. **Flexión lean planche con déficit** `flex_lean_planche_deficit` (dos apoyos elevados) — PetruWorkout 30:10
   - ↑ Solo cuando la versión estándar sea cómoda y controlada
4. **Flexión tuck planche** `flex_tuck_planche` (paralelas bajas (recomendable)) — PetruWorkout 30:29; Bruno Focacci 7:02
   - ✓ Rodillas al pecho, pies en el aire, hombros adelantados
   - ↑ Antes: mantener la tuck planche estática al menos ~5 s
   - ↑ Empezar cuando el tuck es sólido (15 s) (Bruno Focacci)
5. **Flexión advanced tuck planche** `flex_adv_tuck_planche` — PetruWorkout 31:10
   - ✓ Rodillas más separadas del pecho, cuerpo más horizontal
6. **Flexión straddle planche** `flex_straddle_planche` — PetruWorkout 31:29; PetruWorkout 7:47
   - ✓ Piernas estiradas y abiertas en V
   - ℹ El autor la muestra con goma
7. **Flexión full planche** `flex_full_planche` — PetruWorkout 31:58
   - ✓ Piernas juntas, cuerpo horizontal

## Press a pino desde tuck (`press_plancha`)

1. **Negativa de press a tuck planche** `tuck_press_negativa` (negativa) — Bruno Focacci 7:55; Pedro Gadez 2:51
   - ✓ Desde el pino, al bajar lleva las rodillas al pecho
   - ✓ No pienses en bajar: resiste con la palanca de hombro
   - ✓ Inclínate sin miedo, codos bloqueados; el peso va delante de la muñeca y luego atrás
   - ↑ 4 de 4 sin fallar, lenta y aguantando 10 s abajo antes de intentar el press (Pedro Gadez)
2. **Press a tuck planche con goma** `tuck_press_goma` (goma elástica, paralelas) — Pedro Gadez 7:38; Bruno Focacci 9:43
   - ↑ Una goma que te deje hacer 2–5 repeticiones (Bruno Focacci)
   - ℹ La goma sirve para aprender el movimiento, no para construir la fuerza
3. **Press a pino desde tuck, cadera alta** `tuck_press_cadera_alta` — Pedro Gadez 4:58
   - ✓ Cuanto más alta la cadera al empezar, más fácil
   - ↑ 4–6 series cómodas en cada altura antes de bajar la cadera (Pedro Gadez)
4. **Press a pino desde tuck planche (en el sitio)** `tuck_press` — Pedro Gadez 5:25; Bruno Focacci 9:33
   - ✓ Peso delante y, mientras subes, llévalo atrás de la mano
   - ✓ Mete los hombros al final
   - ✓ Arriba frena con las muñecas; deja que la cadera se extienda sola
   - ✓ Serie útil: subida por fuerza + negativa a tuck
   - ✗ Dejar el hombro adelantado y quedarse atascado
   - ✗ Doblar el codo por miedo a caer de cabeza

## Dominadas: de 0 a 10 (`dominada_base`)

1. **Colgarse de la barra** `colgado_barra` (segundos; barra) — PetruWorkout 0:26; PetruWorkout 0:33
   - ↑ Requisito antes de empezar: 20 s (PetruWorkout)
2. **Aguante en la mitad de la dominada** `dominada_isometrico_mitad` (segundos; barra) — PetruWorkout 2:01
   - ↑ 10 s para pasar a negativas (PetruWorkout)
3. **Negativa de dominada** `dominada_negativa` (negativa; barra) — PetruWorkout 2:42
   - ℹ El autor la señala como el ejercicio más importante de la escalera
4. **Negativa con pausas (5 s arriba, medio, abajo)** `dominada_negativa_pausas` (negativa; barra) — PetruWorkout 3:04
5. **Dominada** `dominada` (barra) — PetruWorkout 3:25; PetruWorkout 0:36; Domein 6:28
   - ✓ Brazos completamente estirados abajo, barbilla por encima de la barra, bajada lenta
   - ↑ Con 1–5, perfecciona la técnica; con 10 seguidas × 3 series, pasa a explosivas (PetruWorkout)
   - ↑ Con 15 limpias, progresa a variantes en vez de sumar repeticiones (PetruWorkout)
   - ℹ Ejemplo de principiante: 3–5 series de 2–5, completando con negativas

## Dominada explosiva → cadera (`tiron_explosivo`)

_Orden mezclando dos fuentes: ver conflictos_

1. **Dominada explosiva (pecho a la barra)** `dominada_explosiva` (barra) — PetruWorkout 5:00; Eryc Ortiz 0:50; algecalistenia 7:11
   - ✓ Sube lo más alto posible; objetivo, el pecho toca la barra
   - ✓ Si solo salen 3–4 buenas, sigue con normales con intención de subir
   - ✓ Menos repeticiones, más intensas
   - ↑ Series de 3–4 repeticiones; para cuando pierdas velocidad o altura (algecalistenia)
2. **Muscle up** `muscle_up` (barra) — PetruWorkout 5:30; PetruWorkout 7:18
   - ✓ Aléjate de la barra para poder meter la cabeza arriba
   - ↑ Mínimo 5 repeticiones con buena técnica (PetruWorkout)
   - ↑ Con 10 dominadas sin esfuerzo ya puedes trabajar explosivas y muscle up (PetruWorkout)
3. **Dominada alta (abdomen a la barra)** `dominada_abdomen` (barra) — Eryc Ortiz 1:37
4. **Dominada a la cadera** `dominada_cadera` (barra) — Eryc Ortiz 2:03; PetruWorkout 6:31

## Camino a la dominada a una mano (`tiron_una_mano`)

1. **Aguante a una mano en la mitad** `aguante_una_mano` (segundos; barra) — PetruWorkout 6:55
   - ✓ Sube a la mitad, suelta un brazo y aguanta; luego el otro
2. **Negativa de dominada a una mano** `negativa_una_mano` (negativa; barra) — PetruWorkout 7:20; PetruWorkout 12:22
   - ✓ Barbilla sobre la barra con un brazo y baja lento
   - ✓ Ambos brazos por igual; no dejes las dominadas a dos brazos
3. **Dominada a una mano asistida (goma o apoyo)** `dominada_una_mano_asistida` (barra, goma elástica) — PetruWorkout 12:22
4. **Dominada a una mano** `dominada_una_mano` (barra) — PetruWorkout 12:00
   - ✗ Quedarse a mitad de recorrido

## Dominadas de volumen (`tiron_volumen`)

1. **Dominada** `dominada` (barra) — PetruWorkout 3:25; PetruWorkout 0:36; Domein 6:28
   - ✓ Brazos completamente estirados abajo, barbilla por encima de la barra, bajada lenta
   - ↑ Con 1–5, perfecciona la técnica; con 10 seguidas × 3 series, pasa a explosivas (PetruWorkout)
   - ↑ Con 15 limpias, progresa a variantes en vez de sumar repeticiones (PetruWorkout)
   - ℹ Ejemplo de principiante: 3–5 series de 2–5, completando con negativas
2. **Dominada en L** `dominada_l` (barra) — PetruWorkout 6:08
   - ✓ Abdomen firme: el cuerpo entero como una pieza

## Dominada lastrada (`dominada_lastre`)

1. **Dominada lastrada** `dominada_lastrada` (barra, mochila con peso) — PetruWorkout 6:31
   - ℹ El autor pone 50–60 kg como meta de nivel 10. El sistema de subir de kilos en kilos es del tracker, no de las fuentes

## Remo australiano (`remo`)

1. **Remo australiano con rodillas flexionadas** `remo_australiano_rodillas` (barra baja) — PetruWorkout 1:35
2. **Remo australiano** `remo_australiano` (barra baja) — PetruWorkout 1:02; PetruWorkout 1:37; PetruWorkout 1:08
   - ✓ Brazos totalmente estirados abajo; pecho a la barra arriba
   - ✓ Barra más alta = más fácil; inclínate más para endurecerlo
   - ✓ Cuanto más horizontal, más duro
3. **Remo australiano horizontal (barra baja)** `remo_australiano_horizontal` (barra baja) — PetruWorkout 2:01
4. **Remo arquero** `remo_arquero` (barra baja) — PetruWorkout 2:05
5. **Remo a un brazo** `remo_un_brazo` (barra baja) — PetruWorkout 2:05

## Front lever (`front_lever`)

1. **Tuck front lever** `fl_tuck` (segundos; barra) — PetruWorkout 12:55
   - ✓ Rodillas pegadas al pecho
2. **Advanced tuck front lever** `fl_adv_tuck` (segundos; barra) — PetruWorkout 13:25
   - ✓ Aleja las rodillas del pecho poco a poco
3. **Front lever con goma** `fl_goma` (segundos; barra, goma elástica) — PetruWorkout 13:25

## Back lever (`back_lever`)

1. **Skin the cat** `skin_the_cat` (barra) — PetruWorkout 10:43
2. **Back lever** `back_lever` (segundos; barra) — PetruWorkout 10:23
   - ✓ Manos juntas
   - ✓ Empieza arriba y baja poco a poco hasta la horizontal
   - ℹ Requiere tríceps: muchos fondos

## Core colgado (`core_colgado`)

1. **Elevación de rodillas colgado** `elevacion_rodillas` (barra) — PetruWorkout 3:46
   - ℹ Ayuda al L-sit
2. **Elevación de piernas colgado** `elevacion_piernas_colgado` (barra) — PetruWorkout 6:32
3. **Pies a la barra (toes to bar)** `toes_to_bar` (barra) — PetruWorkout 6:40

## Core en el suelo (`core_suelo`)

1. **Plancha abdominal** `plancha_abdominal` (segundos) — PetruWorkout 0:46; PetruWorkout 5:33
   - ✓ Cadera ni arriba ni abajo: línea recta
   - ✗ Hundir la zona lumbar o subir la cadera
   - ↑ Requisito antes de empezar: 30 s estrictos (PetruWorkout)
   - ℹ Calidad antes que duración
2. **Elevación de piernas en el suelo** `elevacion_piernas_suelo` — PetruWorkout 6:19; Eryc Ortiz 3:22
   - ✓ Baja lento, controlando
3. **Elevación de piernas con cadera arriba (candlestick)** `candlestick` — Eryc Ortiz 3:47
   - ✓ Tras subir las piernas, lleva la cadera arriba activando dorsales, lumbares y abdomen
   - ℹ Según el autor ayuda al front lever

## L-sit (`lsit`)

1. **Tuck L-sit (rodillas flexionadas)** `lsit_tuck` (segundos; paralelas) — PetruWorkout 3:38
   - ↑ Aguanta lo máximo; con 20–30 s, si las piernas no se estiran, añade movilidad (PetruWorkout)
2. **L-sit** `lsit` (segundos; paralelas) — PetruWorkout 4:07
   - ℹ Subir y mantener las piernas depende más de la fuerza de abdomen que de la flexibilidad

## Fondos (`fondos`)

1. **Fondos en paralelas** `fondos` (paralelas) — PetruWorkout 2:58; Eryc Ortiz 2:28; Bruno Focacci 0:02
   - ✓ Principiantes: codo por encima de 90º
   - ✓ Con pequeños cambios enfatizas pecho o tríceps
   - ✓ Pecho hacia dentro y hombros hacia atrás y abajo (depresión escapular)
   - ✓ Inclínate un poco; si pierdes la posición abajo, reactívala arriba
   - ✗ Bajar demasiado o abrir mucho los codos (irrita el hombro)
   - ↑ Base antes de entrenar plancha: 20–25 fondos y 30 flexiones (Bruno Focacci)
   - ℹ Según Eryc Ortiz, esta versión ayuda a la plancha
2. **Fondos rusos** `fondos_rusos` (paralelas) — PetruWorkout 1:58

## Fondos lastrados (`fondos_lastre`)

1. **Fondos lastrados** `fondos_lastrados` (paralelas, mochila con peso) — PetruWorkout 2:58
   - ℹ El lastre es el método del tracker; las fuentes solo piden muchos fondos

## Tiger bend (`tiger`)

1. **Tiger bend negativa** `tiger_bend_negativa` (negativa) — PetruWorkout 16:50
   - ✓ Bajar lento hasta apoyar antebrazos; volver arriba apoyando rodillas
2. **Tiger bend push-up** `tiger_bend` — PetruWorkout 16:16
   - ✓ Bajar hasta apoyar los antebrazos y empujar hasta estirar los brazos
   - ℹ Según el autor, de los mejores para preparar hombro y tríceps de cara a la plancha

## Fuera de escaleras

- **Flexión hindú** `flex_hindu` — PetruWorkout 7:39
- **Lean planche pike (subir la cadera por palanca)** `lean_pica` — Bruno Focacci 2:59
- **Fondos escapulares con protracción** `fondos_protraccion` — Bruno Focacci 4:39
- **Negativa de pino a straddle planche** `straddle_negativa` — Bruno Focacci 12:00
- **Plancha lateral** `plancha_lateral` — PetruWorkout 11:24
- **Aguante con la barbilla sobre la barra** `aguante_barbilla` — PetruWorkout 6:50
- **Pull over** `pull_over` — PetruWorkout 6:50
- **Aguante hollow body** `hollow_body` — Domein 4:06
- **Sentadilla con peso corporal** `sentadilla` — PetruWorkout 7:43
- **Sentadilla isométrica en la pared** `sentadilla_pared` — PetruWorkout 8:00
- **Burpee** `burpee` — PetruWorkout 8:16
- **Saltos a la comba (real o imaginaria)** `comba` — PetruWorkout 7:11
- **Retracciones escapulares colgado** `retraccion_colgado` — Domein 4:06
- **Protracciones en paralelas** `protraccion_paralelas` — Domein 4:06
